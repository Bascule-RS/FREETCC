
let graph1 = {
    1: {
        situation: 'soirée',
        emotion: 5,
        'pensées_auto ': 'je suis nul ',
        confirmation: 'on me parle peu ',
        preuves_contraires: "Je sais que Simon m'aime bien et il compte pour moi",
        pensée_adaptée: "j'ai des qualités",
        emotion_resultat: 2
    },
    2: {
        situation: 'soirée ',
        emotion: 6,
        'pensées_auto ': "je n'interesse personne",
        confirmation: " personne ne me parle ",
        preuves_contraires: "j'ai des amis",
        pensée_adaptée: "Je ne connais quasiment personne et j'ai le droit d'être discret ",
        emotion_resultat: 3
    },
    3: {
        situation: 'soirée',
        emotion: 5,
        'pensées_auto ': 'je suis le seul à ne pas danser',
        confirmation: "je suis coincé",
        preuves_contraires: "Des gens cools ne dansent pas.. ",
        pensée_adaptée: "Je sais que je suis plutot cool et ouvert d'esprit",
        emotion_resultat: 3
    },
    4: {
        situation: 'soirée',
        emotion: 4,
        'pensées_auto ': "je n'ose pas aller vers les gens",
        confirmation: "je ne sais pas comment les aborder",
        preuves_contraires: " certaines personnes tres intelligentes sont en retrait ",
        pensée_adaptée: "Je sais que je suis interessant",
        emotion_resultat: 2
    }
};
let graph2 = {
    1: {
        situation: 'dîner',
        emotion: 6,
        'pensées_auto ': 'je suis nul ',
        confirmation: 'je ne sais pas quoi dire',
        preuves_contraires: "J'ai des amis qui m'aiment",
        pensée_adaptée: "j'ai des qualités",
        emotion_resultat: 3
    },
    2: {
        situation: 'dîner ',
        emotion: 6,
        'pensées_auto ': "je n'interesse personne",
        confirmation: " personne ne me parle ",
        preuves_contraires: "j'ai des amis",
        pensée_adaptée: "Je ne connais quasiment personne et j'ai le droit d'être discret ",
        emotion_resultat: 3
    },
    3: {
        situation: 'dîner ',
        emotion: 5,
        'pensées_auto ': "l'impression d'avoir saoulé tout le monde avec mon invervention",
        confirmation: "ça a laissé un froid",
        preuves_contraires: "Les gens ne s'interessent qu'à eux",
        pensée_adaptée: "Je sais que je suis cultivé",
        emotion_resultat: 3
    }
};


let object_global = {1: graph1, 2: graph2};